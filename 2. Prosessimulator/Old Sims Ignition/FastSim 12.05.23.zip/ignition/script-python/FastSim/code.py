
#Bibliotek
import math
import time
import random
import array
import sys

#%% Pris

pris_kaskade = 0
pris_smartstyring = 0

# Oppretter Pumpestyringsprofil array 
timer = 24
StyringsProfilArray = array.array('d', [0] * timer)
StyringsProfilSekundforSekund = []

# Oppretter array for strømpriser
StromPrisArray = array.array('d', [0] * timer)
StromPrisSekundforSekund = []

#Endrer styringsprofilarray fra timer til sekunder
for i in range(timer):
    StyringsProfilArray[i] = system.tag.readBlocking("Pumpestyringsprofil")[0].value[i]
    StromPrisArray[i] = system.tag.readBlocking("DagensPriser")[0].value[i]
    for t in range(60*60):
        StyringsProfilSekundforSekund.append(StyringsProfilArray[i])
        StromPrisSekundforSekund.append(StromPrisArray[i]) # [Kr/kWt]

#%% Instrument parameter
MaaleAvvikNivaa = 0.0 # [%]
MaaleAvvikStromning = 0.0 # [%]

#%% Simulation Time Settings
t_start = 0  # [s]
t_stop = 60*60*timer # [s]

#%% Signal parameter
u_min = 0 # [mA]
u_max = 16 # [mA]
u_range = u_max - u_min # [mA]

#%% Reservoir parameter
reservoir_h_max = system.tag.read("BassengHoyde").value # 7 [m]
reservoir_h_min = 0 # [m]
reservoir_radius = system.tag.read("BassengRadius").value # 11 [m]
reservoir_h_init = 2.8 # [m]

#%% Pumpe parameter
pumpe_energiforbruk = system.tag.read("PumpeEffekt").value # kW/t ved max

# kW/h per mA (styresignal)
pumpe_energi_forbruk_per_mA = pumpe_energiforbruk / 16.0 # [kWt/mA]

# kW/s per mA (Styresignal)
pumpe_energi_forbruk_per_s_per_mA = pumpe_energi_forbruk_per_mA / 3600 # [kWs/mA]

pumpe_q_max_t = system.tag.read("PumpeMaksStromning").value # 120 [m^3/t] - Volumetrisk strømning ved maks pådrag. Funnet ved 120m^3 / 60s*60s
pumpe_q_max_s = pumpe_q_max_t / (60*60) # 0.033 [m^3/s]
pumpe_q_min = 0 # [m^3/s] - Volumetrisk strømning ved 4 mA (0 mA per nå)
pumpe_q_init = 0.015 # [m^3/s] - Volumetrisk strømning ved første iterasjon | funnet ved totalstrømning fra begge pumpene / timer / 60*60
# 27.01.23 En forenklet versjon som ikke tar for seg mottrykk (net head) i røret og antatt linear pumpekurve

def ReturnK_p(pumpe_q_max, pumpe_q_min, u_range):
    k_p = (pumpe_q_max - pumpe_q_min) / u_range
    return k_p

k_p = ReturnK_p(pumpe_q_max_s, pumpe_q_min ,u_range) # Forholdet mellom pådragssignal og volumetrisk strømning


#%% Innløpsventil parameter
C_v1 = 0.005 # [x] Valve flow coefficient

#%% Utløpsventil parameter
C_v2 = 0.005 # [x] Valve flow coefficient
init = round(math.sqrt(reservoir_h_init) * C_v2, 3)

#%% Primærsløyfe nivå-PI(D)-regulator parameter
ol_P = system.tag.read("ProporsjonalVerdiPrimaer").value
ol_I = system.tag.read("IntegralVerdiPrimaer").value
ol_D = system.tag.read("DerivatVerdiPrimaer").value
ol_u_man = system.tag.read("ManueltPaadragPrimaer").value
ol_settpunkt = 2.8
ol_modus = system.tag.read("PrimaerRegulatorModus").value


#%% Sekundærsløyfe strømnings-PI(D)-regulator parameter
il_P = system.tag.read("ProporsjonalVerdiSekundaer").value
il_I = system.tag.read("IntegralVerdiSekundaer").value
il_D = system.tag.read("DerivatVerdiSekundaer").value
il_u_man = system.tag.read("ManueltPaadragSekundaer").value
il_modus = system.tag.read("SekundaerRegulatorModus").value
il_pv_init = pumpe_q_init
il_sp_init = init

#%% Initialization of time delay flow in
f_delay = 120
N_delay_f = int(round(f_delay/1)) + 1
delay_array = array.array('f', [0] * N_delay_f)

#%% Initialisering av tidsforsinkelse ved måling av strømning
f_meas_delay = int(f_delay/10)
N_delay_meas = int(round(f_meas_delay/1)) + 1
f_meas_delay_array = array.array('f', [0] * N_delay_meas)

#%% Klasser 
def clip(x, xmin, xmax):
    return max(min(x, xmax), xmin)
    
class DataLagring:
    def __init__(self, t, h_t, f_in_t, f_out_t, settpunkt):
        self.t = t # Blir brukt som tid og indeks
        self.h_t = h_t # Høyden i bassenget som funksjon av tid
        self.f_in_t = f_in_t # Flow in som funksjon av tid, fått av pump.Flow()
        self.f_out_t = f_out_t # f_out_t # flow ut som funksjon av tid, fått av Reservoir.FlowOut()
        self.settpunkt = settpunkt
        self.u = pumpe_q_init # Muligens feil
        
        # Arrays til plotting | kaskade
        self.t_array = array.array('f', [0] * t)
        self.h_t_array = array.array('f', [0] * t)
        self.f_in_t_array = array.array('f', [0] * t)
        self.f_out_t_array = array.array('f', [0] * t)
        self.settpunkt_array = array.array('f', [0] * t)
        self.u_f_array = array.array('f', [0] * t)
        self.u_h_array = array.array('f', [0] * t)
        self.e_array = array.array('f', [0] * t)
        self.pris_kaskade_array = array.array('f', [0] * t)
        self.il_u_i_forrige_array = array.array('f', [0] * t)
        self.ul_u_i_forrige_array = array.array('f', [0] * t)
    	
    	# Arrays til plotting | smartstyring
    	self.h_t_array_smart = array.array('f', [0] * t)
    	self.f_in_t_array_smart = array.array('f', [0] * t)
    	self.u_f_array_smart = array.array('f', [0] * t)
    	self.pris_smartstyring_array = array.array('f', [0] * t)
class Reservoir:
    def __init__(self, h_max, h_min, radius, h_init):
        
        self.h_max = h_max
        self.h_min = h_min
        self.radius = radius
        self.areal = self.Areal()
        self.h = h_init
        
        # Avgrens min og maks nivå i tank
        self.h = clip(self.h, self.h_min, self.h_max)
        self.h_prosent = (self.h/self.h_max)*100
        
    def Areal(self):
    	
        reservoir_areal = math.pi*self.radius**2
        return reservoir_areal
    
    def StatiskForbruk(self):
    	
        flowOut = C_v2 * math.sqrt(self.h)
        return flowOut
        
class Pumpe:
    def __init__(self, K_p, u_min, u_max, u):
        
        self.K_p = K_p # [%] forsterkning
        self.u = u # [mA] pådragssignal
        self.u_max = u_max # [mA]
        self.u_min = u_min # [mA]
        

    def FlowIn(self):
        flowIn = self.K_p * self.u 
        return flowIn # [m^3/s]

class OuterLoopRegulator:
    def __init__(self, settpunkt, prosessverdi, P, I, D, u_man, modus):
        
        self.settpunkt = settpunkt
        self.prosessverdi = prosessverdi
        self.P = P
        self.I = I
        self.D = D
        self.u_man = u_man
        self.modus = modus 
        self.u_i_forrige = u_man 
        self.e = self.Error()
        self.u = self.Paadrag()
        
    def Error(self):
        e = self.settpunkt - self.prosessverdi
        return e
    
    def Paadrag(self):
        if self.modus == True:
            # Bidrag fra proporsjonalleddet
            u_p = self.P * self.e
            
            # Bidraget fra integralleddet
            u_i = ((self.P / self.I) * self.e) + self.u_i_forrige
            
            # Regn ut total total forsterkning
            u = u_p + u_i # u_d | ikke implementert
            
            #Oppdater u_i_forrige + antiwindup
            if u > 0.033: # 16
                self.u_i_forrige = self.u_i_forrige
            elif u < 0:
                self.u_i_forrige = self.u_i_forrige
            else:   
                self.u_i_forrige = u_i
            
        elif self.modus == False:
            # Manuell drift
            u = self.u_man
            
        else:
            # Feilmelding
            pass
            
        # Begrens pådragssignal til gitte rammer
        u = clip(u, 0, 0.033) # u_min, u_max
        return u

class InnerLoopRegulator:
    def __init__(self, settpunkt, prosessverdi, P, I, D, u_man, modus):
        
        self.settpunkt = settpunkt
        self.prosessverdi = prosessverdi
        self.P = P
        self.I = I
        self.D = D
        self.u_man = u_man
        self.modus = modus
        self.u_i_forrige = u_man 
        self.e = self.Error()
        self.u = self.Paadrag()
        
    def Error(self):
        e = self.settpunkt - self.prosessverdi
        return e
        
    def Paadrag(self):
        if self.modus == True:
                
            # Bidrag fra proporsjonalleddet
            u_p = self.P * self.e
                
            # Bidraget fra integralleddet
            u_i = (self.P / self.I) * self.e + self.u_i_forrige
                
            # Regn ut totalforsterkning
            u = u_p + u_i # + u_d | u_d ikke implementert
                
            #Oppdater u_i_forrige + antiwindup
            if u > 16:
                self.u_i_forrige = self.u_i_forrige
            elif u < 0:
                self.u_i_forrige = self.u_i_forrige
            else:   
                self.u_i_forrige = u_i
            
        elif self.modus == False:
            # Manuell drift
            u = self.u_man
            
        else:
            # Feilmelding
            pass
                
        # Begrens pådrag til gitte rammer
        u = clip(u, u_min, u_max)
        return u
                

class Instrument:
    def __init__(self, prosessverdi, maaleavvik):
        
        self.prosessverdi = prosessverdi
        self.maaleavvik = maaleavvik
        
        def PVstoy(self):
            pass

class Nivaamaaler(Instrument):
    def PVstoy(self):
        PVavvik = (self.prosessverdi * self.maaleavvik) / 100 
        PVstoy = random.uniform(self.prosessverdi - PVavvik, self.prosessverdi + PVavvik)
        return PVstoy

class Stromningsmaaler(Instrument):
    def PVstoy(self):
        PVavvik = (self.prosessverdi * self.maaleavvik) / 100 
        PVstoy = random.uniform(self.prosessverdi - PVavvik, self.prosessverdi + PVavvik)
        return PVstoy
           
#%% Opprett objekter av klassene
mittReservoir = Reservoir(reservoir_h_max, reservoir_h_min, reservoir_radius, reservoir_h_init)
outerLoopRegulator = OuterLoopRegulator(ol_settpunkt, mittReservoir.h, ol_P, ol_I, ol_D, ol_u_man, ol_modus)
innerLoopRegulator = InnerLoopRegulator(outerLoopRegulator.Paadrag(), il_pv_init, il_P, il_I, il_D, il_u_man, il_modus)
minPumpe = Pumpe(k_p, u_min, u_max, innerLoopRegulator.Paadrag())
minDataLagring = DataLagring(t_stop, mittReservoir.h, minPumpe.FlowIn(), mittReservoir.StatiskForbruk(), outerLoopRegulator.settpunkt)
minNivaamaaler = Nivaamaaler(mittReservoir.h, MaaleAvvikNivaa)
minStromningsmaaler = Stromningsmaaler(minPumpe.FlowIn(), MaaleAvvikStromning)


#%% Program-loop

# Denne løkken simulerer fullt innløp
for h in range (f_meas_delay + 1):
    f_meas_delay_array[h] = init

# Simulerer null delay på måling i startfasen
for j in range (f_meas_delay + 1):
    f_meas_delay_array[j] = init


for sim in range(2):
    mittReservoir.h = reservoir_h_init
    for t in range (t_start, t_stop):
        # forsinker innstrømning i tanken med 120 iterasjoner | bare valgt et tall her
        f_in_delayed = delay_array[-1]
        delay_array[1:] = delay_array[0:-1]
        delay_array[0] = minPumpe.FlowIn()
        
        # dh_dt = f_in - f_out / A
        dh_dt = (f_in_delayed - mittReservoir.StatiskForbruk()) / mittReservoir.Areal() # | *60 for minutter istedet for sekunder
        
        # Mitt reservoir.h oppdaterer høyden i tanken per iterasjon
        mittReservoir.h += dh_dt
        
        # Måler nivå med Nivåmåler
        minNivaamaaler.prosessverdi = mittReservoir.h
        
        # Oppdater outer loop regulatoren PV | med støy
        outerLoopRegulator.prosessverdi = minNivaamaaler.PVstoy()
        
        # Oppdater outer loop error
        outerLoopRegulator.e = outerLoopRegulator.Error()
        
        # Send outerLoop u til inner loop SP
        innerLoopRegulator.settpunkt = outerLoopRegulator.Paadrag()
        
        # Forsinker strømningsmåling med 12 sekunder
        f_meas_delayed = f_meas_delay_array[-1]
        f_meas_delay_array[1:] = f_meas_delay_array[0:-1]
        f_meas_delay_array[0] = minPumpe.FlowIn()
        
        # Måler strømning med strømningsmåler
        minStromningsmaaler.prosessverdi = f_meas_delayed
        
        # Oppdater sekundær regulator PV
        innerLoopRegulator.prosessverdi = minStromningsmaaler.PVstoy()
        
        # Oppdater inner loop error
        innerLoopRegulator.e = innerLoopRegulator.Error()
        
        # Simulerer kaskaderegulering uten smartstyring
        if sim == 0:
            
            # Generer nytt pådrag til pumpa
            minPumpe.u = innerLoopRegulator.Paadrag()
            
            # Lagring av verdier fra kaskaderegulering
            minDataLagring.h_t_array[t] = minNivaamaaler.PVstoy()
            minDataLagring.f_in_t_array[t] = minStromningsmaaler.PVstoy()
            minDataLagring.u_f_array[t] = minPumpe.u
            minDataLagring.pris_kaskade_array[t] = minPumpe.u * pumpe_energi_forbruk_per_s_per_mA * StromPrisSekundforSekund[t]
            
            # Lagrer pris
            pris_kaskade += minDataLagring.pris_kaskade_array[t]
        
        # Simulerer kaskaderegulering med smartstyring
        elif sim == 1:
            
            # Generer nytt pådrag til pumpa dersom smartstyringen tillater det
            if StyringsProfilSekundforSekund[t] == 1:
                minPumpe.u = innerLoopRegulator.Paadrag()
             
            elif innerLoopRegulator == False:
                minPumpe.u = innerLoopRegulator.Paadrag()
            else:    
                minPumpe.u = 0
                
            # Lagring av verdier fra smartstyring  
        minDataLagring.h_t_array_smart[t] = minNivaamaaler.PVstoy()
        minDataLagring.f_in_t_array_smart[t] = minStromningsmaaler.PVstoy()
        minDataLagring.u_f_array_smart[t] = minPumpe.u
        minDataLagring.pris_smartstyring_array[t] = minPumpe.u * pumpe_energi_forbruk_per_s_per_mA * StromPrisSekundforSekund[t] # [mA * kWs/mA * Kr/kWs = Kr]
		#pris_smartstyring += minDataLagring.pris_smartstyring_array[t]   
        


        # Lagring av verdier til Datalagringsklassen
        minDataLagring.t_array[t] = t
        #minDataLagring.h_t_array[t] = minNivåmåler.PVstøy()
        #minDataLagring.f_in_t_array[t] = minStrømningsmåler.PVstøy()
        minDataLagring.f_out_t_array[t] = mittReservoir.StatiskForbruk()
        minDataLagring.settpunkt_array[t] = outerLoopRegulator.settpunkt
        #minDataLagring.u_f_array[t] = innerLoopRegulator.Pådrag()
        #minDataLagring.u_f_array[t] = minPumpe.u
        minDataLagring.u_h_array[t] = outerLoopRegulator.Paadrag()
        minDataLagring.e_array[t] = outerLoopRegulator.e
        minDataLagring.il_u_i_forrige_array[t] = innerLoopRegulator.u_i_forrige
        minDataLagring.ul_u_i_forrige_array[t] = outerLoopRegulator.u_i_forrige

# Lagrer pris dette kunne ikke stå i løkken over!!                        
for t in range (t_start, t_stop):
	pris_smartstyring += minDataLagring.pris_smartstyring_array[t]
system.tag.writeBlocking(["Nivaa"],[(minDataLagring.h_t_array_smart/7)*100])
besparelse = pris_kaskade - pris_smartstyring
system.tag.writeBlocking(["KaskadePris"], [pris_kaskade])
system.tag.writeBlocking(["SmartPris"], [pris_smartstyring])
system.tag.writeBlocking(["Besparelse"], [besparelse])
system.tag.writeBlocking(["BesparelseProsent"], [(besparelse/pris_kaskade)*100])

	