
#Bibliotek
import math
import time
import random
import array


speed = system.tag.read("Speed").value

# Oppretter Pumpestyringsprofil array 
timer = 24
styringsProfilArray = array.array('d', [0] * timer)
stromPrisArrayDagensSekundforSekund = []
#Endrer styringsprofilarray fra timer til sekunder
for i in range(timer):
    styringsProfilArray[i] = system.tag.readBlocking("Pumpestyringsprofil")[0].value[i]
    for t in range(60*60):
        stromPrisArrayDagensSekundforSekund.append(styringsProfilArray[i])

#%% Instrument parameter
MaaleAvvikNivaa = 0.0 # [%]
MaaleAvvikStromning = 0.0 # [%]

#%% Simulation Time Settings
t_start = 0  # [s]
t_stop = 60*60*timer # [s]

#%% Signal parameter
u_min = 0 # [mA]
u_max = 16 # [mA]
u_range = u_max - u_min # [mA]

#%% Reservoir parameter
reservoir_h_max = 7 # [m]
reservoir_h_min = 0 # [m]
reservoir_radius = 11 # [m]
reservoir_h_init = 2.8 # [m]

#%% Pumpe parameter
pumpe_q_max = 0.033 # [m^3/s] - Volumetrisk strømning ved maks pådrag. Funnet ved 120m^3 / 60s*60s
pumpe_q_min = 0 # [m^3/s] - Volumetrisk strømning ved 4 mA
pumpe_q_init = 0.015 # [m^3/s] - Volumetrisk strømning ved første iterasjon | funnet ved totalstrømning fra begge pumpene / timer / 60*60
# 27.01.23 En forenklet versjon som ikke tar for seg mottrykk (net head) i røret og antatt linear pumpekurve

def ReturnK_p(pumpe_q_max, u_range):
    k_p = (pumpe_q_max - pumpe_q_min) / u_range
    return k_p

k_p = ReturnK_p(pumpe_q_max, u_range) # Forholdet mellom pådragssignal og volumetrisk strømning


#%% Innløpsventil parameter
C_v1 = 0.005 # [x] Valve flow coefficient

#%% Utløpsventil parameter
C_v2 = 0.005 # [x] Valve flow coefficient
init = round(math.sqrt(reservoir_h_init) * C_v2, 3)

#%% Primærsløyfe nivå-PI(D)-regulator parameter
ol_Kpu = 2 # Kritisk Forsterkning # 40.035
ol_Pu = 3000 # [s] Kritisk Periode # 483
ol_P = ol_Kpu*0.25 # proporsjonal forsterkning | ZN Relaxed
ol_I = ol_Pu*1.25 # Integraltid | ZN Relaxed
ol_D = 0 # Derivattid
ol_u_man = init # Manuelt pådrag | Stabiliserer seg på 40% ved 0.008365 i pådrag ved inner loop i auto
ol_settpunkt = 2.8 # Settpunkt i tanken | 40% i en 7m høy tank
ol_modus = "auto"

#%% Sekundærsløyfe strømnings-PI(D)-regulator parameter
il_Kpu = 484.81 # Kritisk Forsterkning
il_Pu = 28 # Kristisk Periode
il_P = il_Kpu*0.25 # Proporsjonal forsterkning
il_I = il_Pu*1.25 # Intergraltid
il_D = 0 # Derivattid
il_u_man = 4.0566 # Manuelt pådrag
il_pv_init = pumpe_q_init
il_sp_init = init
il_modus = "auto"

#%% Initialization of time delay flow in
f_delay = 120
N_delay_f = int(round(f_delay/1)) + 1
delay_array = array.array('f', [0] * N_delay_f)

#%% Initialisering av tidsforsinkelse ved måling av strømning
f_meas_delay = int(f_delay/10)
N_delay_meas = int(round(f_meas_delay/1)) + 1
f_meas_delay_array = array.array('f', [0] * N_delay_meas)

#%% Klasser 
def clip(x, xmin, xmax):
    return max(min(x, xmax), xmin)
    
class DataLagring:
    def __init__(self, t, h_t, f_in_t, f_out_t, settpunkt):
        self.t = t # Blir brukt som tid og indeks
        self.h_t = h_t # Høyden i bassenget som funksjon av tid
        self.f_in_t = f_in_t # Flow in som funksjon av tid, fått av pump.Flow()
        self.f_out_t = f_out_t # f_out_t # flow ut som funksjon av tid, fått av Reservoir.FlowOut()
        self.settpunkt = settpunkt
        self.u = pumpe_q_init # Muligens feil
        
        # Arrays til plotting | simulering
        self.t_array = array.array('f', [0] * t)
        self.h_t_array = array.array('f', [0] * t)
        self.f_in_t_array = array.array('f', [0] * t)
        self.f_out_t_array = array.array('f', [0] * t)
        self.settpunkt_array = array.array('f', [0] * t)
        self.u_f_array = array.array('f', [0] * t)
        self.u_h_array = array.array('f', [0] * t)
        self.e_array = array.array('f', [0] * t)
        self.il_u_i_forrige_array = array.array('f', [0] * t)
        self.ul_u_i_forrige_array = array.array('f', [0] * t)
    
class Reservoir:
    def __init__(self, h_max, h_min, radius, h_init):
        
        self.h_max = h_max
        self.h_min = h_min
        self.radius = radius
        self.areal = self.Areal()
        self.h = h_init
        
        # Avgrens min og maks nivå i tank
        self.h = clip(self.h, self.h_min, self.h_max)
        self.h_prosent = (self.h/self.h_max)*100
        
    def Areal(self):
        reservoir_areal = math.pi*self.radius**2
        return reservoir_areal
    
    def StatiskForbruk(self):
        flowOut = C_v2 * math.sqrt(self.h)
        return flowOut
        
class Pumpe:
    def __init__(self, K_p, u_min, u_max, u):
        
        self.K_p = K_p # [%] forsterkning
        self.u = u # [mA] pådragssignal
        self.u_max = u_max # [mA]
        self.u_min = u_min # [mA]
        

    def FlowIn(self):
        flowIn = self.K_p * self.u 
        return flowIn # [m^3/s]

class OuterLoopRegulator:
    def __init__(self, settpunkt, prosessverdi, P, I, D, u_man, modus):
        
        self.settpunkt = settpunkt
        self.prosessverdi = prosessverdi
        self.P = P
        self.I = I
        self.D = D
        self.u_man = u_man
        self.modus = modus.upper() # ".upper()" forhindrer syntax error ved store og små bokstaver
        self.u_i_forrige = u_man 
        self.e = self.Error()
        self.u = self.Paadrag()
        
    def Error(self):
        e = self.settpunkt - self.prosessverdi
        return e
    
    def Paadrag(self):
        if self.modus == "AUTO":
            # Bidrag fra proporsjonalleddet
            u_p = self.P * self.e
            
            # Bidraget fra integralleddet
            u_i = ((self.P / self.I) * self.e) + self.u_i_forrige
            
            # Regn ut total total forsterkning
            u = u_p + u_i # u_d | ikke implementert
            
            #Oppdater u_i_forrige + antiwindup
            if u > 0.033: # 16
                self.u_i_forrige = self.u_i_forrige
            elif u < 0:
                self.u_i_forrige = self.u_i_forrige
            else:   
                self.u_i_forrige = u_i
            
        elif self.modus == "MAN":
            # Manuell drift
            u = self.u_man
            
        else:
            # Feilmelding
            print("Vennligst skriv MAN eller AUTO")
            
        # Begrens pådragssignal til gitte rammer
        u = clip(u, 0, 0.033) # u_min, u_max
        return u

class InnerLoopRegulator:
    def __init__(self, settpunkt, prosessverdi, P, I, D, u_man, modus):
        
        self.settpunkt = settpunkt
        self.prosessverdi = prosessverdi
        self.P = P
        self.I = I
        self.D = D
        self.u_man = u_man
        self.modus = modus.upper()
        self.u_i_forrige = u_man 
        self.e = self.Error()
        self.u = self.Paadrag()
        
    def Error(self):
        e = self.settpunkt - self.prosessverdi
        return e
        
    def Paadrag(self):
        if self.modus == "AUTO":
                
            # Bidrag fra proporsjonalleddet
            u_p = self.P * self.e
                
            # Bidraget fra integralleddet
            u_i = (self.P / self.I) * self.e + self.u_i_forrige
                
            # Regn ut totalforsterkning
            u = u_p + u_i # + u_d | u_d ikke implementert
                
            #Oppdater u_i_forrige + antiwindup
            if u > 16:
                self.u_i_forrige = self.u_i_forrige
            elif u < 0:
                self.u_i_forrige = self.u_i_forrige
            else:   
                self.u_i_forrige = u_i
            
        elif self.modus == "MAN":
            # Manuell drift
            u = self.u_man
            
        else:
            # Feilmelding
            print("Vennligst skriv MAN eller AUTO")
                
        # Begrens pådrag til gitte rammer
        u = clip(u, u_min, u_max)
        return u
                

class Instrument:
    def __init__(self, prosessverdi, maaleavvik):
        
        self.prosessverdi = prosessverdi
        self.maaleavvik = maaleavvik
        
        def PVstoy(self):
            pass

class Nivaamaaler(Instrument):
    def PVstoy(self):
        PVavvik = (self.prosessverdi * self.maaleavvik) / 100 
        PVstoy = random.uniform(self.prosessverdi - PVavvik, self.prosessverdi + PVavvik)
        return PVstoy

class Stromningsmaaler(Instrument):
    def PVstoy(self):
        PVavvik = (self.prosessverdi * self.maaleavvik) / 100 
        PVstoy = random.uniform(self.prosessverdi - PVavvik, self.prosessverdi + PVavvik)
        return PVstoy
           
#%% Opprett objekter av klassene
mittReservoir = Reservoir(reservoir_h_max, reservoir_h_min, reservoir_radius, reservoir_h_init)
outerLoopRegulator = OuterLoopRegulator(ol_settpunkt, mittReservoir.h, ol_P, ol_I, ol_D, ol_u_man, ol_modus)
innerLoopRegulator = InnerLoopRegulator(outerLoopRegulator.Paadrag(), il_pv_init, il_P, il_I, il_D, il_u_man, il_modus)
minPumpe = Pumpe(k_p, u_min, u_max, innerLoopRegulator.Paadrag())
minDataLagring = DataLagring(t_stop, mittReservoir.h, minPumpe.FlowIn(), mittReservoir.StatiskForbruk(), outerLoopRegulator.settpunkt)
minNivaamaaler = Nivaamaaler(mittReservoir.h, MaaleAvvikNivaa)
minStromningsmaaler = Stromningsmaaler(minPumpe.FlowIn(), MaaleAvvikStromning)


#%% Program-loop

# Denne løkken simulerer fullt innløp
for i in range ( f_meas_delay):
    f_meas_delay_array[i] = init
    
for t in range (t_start, t_stop):
    # forsinker innstrømning i tanken med 120 iterasjoner | bare valgt et tall her
    f_in_delayed = delay_array[-1]
    delay_array[1:] = delay_array[0:-1]
    delay_array[0] = minPumpe.FlowIn()
    
    # dh_dt = f_in - f_out / A
    dh_dt = (f_in_delayed - mittReservoir.StatiskForbruk()) / mittReservoir.Areal() # | *60 for minutter istedet for sekunder
    
    # Mitt reservoir.h oppdaterer høyden i tanken per iterasjon
    mittReservoir.h += dh_dt
    
    # Måler nivå med Nivåmåler
    minNivaamaaler.prosessverdi = mittReservoir.h
    
    # Oppdater outer loop regulatoren PV | med støy
    outerLoopRegulator.prosessverdi = minNivaamaaler.PVstoy()
    
    # Oppdater outer loop error
    outerLoopRegulator.e = outerLoopRegulator.Error()
    
    # Send outerLoop u til inner loop SP
    innerLoopRegulator.settpunkt = outerLoopRegulator.Paadrag()
    
    # Forsinker strømningsmåleren med 12 sekunder
    f_meas_delayed = f_meas_delay_array[-1]
    f_meas_delay_array[1:] = f_meas_delay_array[0:-1]
    f_meas_delay_array[0] = minPumpe.FlowIn()
    
    # Måler strømning med strømningsmåler
    minStromningsmaaler.prosessverdi = f_meas_delayed
    
    # Oppdater sekundær regulator PV
    innerLoopRegulator.prosessverdi = minStromningsmaaler.PVstoy()
    
    # Oppdater inner loop error
    innerLoopRegulator.e = innerLoopRegulator.Error()
    
    # Generer nytt pådrag til pumpa
    if stromPrisArrayDagensSekundforSekund[t] == 1:
            minPumpe.u = innerLoopRegulator.Paadrag()
    elif innerLoopRegulator.modus == "man":
            minPumpe.u = innerLoopRegulator.Paadrag()
    else:
    	minPumpe.u = 0
            
   
     
    # Lagring av verdier til Datalagringsklassen
    minDataLagring.t_array[t] = t
    minDataLagring.h_t_array[t] = minNivaamaaler.PVstoy()
    minDataLagring.f_in_t_array[t] = minStromningsmaaler.PVstoy()
    minDataLagring.f_out_t_array[t] = mittReservoir.StatiskForbruk()
    minDataLagring.settpunkt_array[t] = outerLoopRegulator.settpunkt
    minDataLagring.u_f_array[t] = innerLoopRegulator.Paadrag()
    minDataLagring.u_h_array[t] = outerLoopRegulator.Paadrag()
    minDataLagring.e_array[t] = outerLoopRegulator.e
    minDataLagring.il_u_i_forrige_array[t] = innerLoopRegulator.u_i_forrige
    minDataLagring.ul_u_i_forrige_array[t] = outerLoopRegulator.u_i_forrige
    
     #Gjør om Verdier til Prosent
    Nivaa_prosent = (minDataLagring.h_t_array[t]/7)*100
    PumpePaadrag = minPumpe.u/(u_max-u_min)*100
    FlowIn = minDataLagring.f_in_t_array[t]*3600
    FlowOut = minDataLagring.f_out_t_array[t]*3600
    time.sleep(1/speed)
    # Skriver til Tag Nivaa
    #system.tag.writeAsync(["Nivaats"],[Nivaa_prosent])
    #system.tag.writeAsync(["PumpePaadrag"],[PumpePaadrag])
    #system.tag.writeAsync(["FlowIn"],[FlowIn])
    #system.tag.writeAsync(["FlowOut"],[FlowOut])
    
    

"""
while system.tag.read("Start").value == True:
    		if system.tag.read("Start").value == True:
        			#Bibliotek
        	 		import math
        	 		import time
        	 		import random
        	 		import array
        	 		import sys
        	 		
        	 		
        	 		speed = system.tag.read("Speed").value
        	 		
        	 		# Oppretter Pumpestyringsprofil array 
        	 		timer = 24
        	 		styringsProfilArray = array.array('d', [0] * timer)
        	 		stromPrisArrayDagensSekundforSekund = []
        	 		#Endrer styringsprofilarray fra timer til sekunder
        	 		for i in range(timer):
        	 		    styringsProfilArray[i] = system.tag.readBlocking("Pumpestyringsprofil")[0].value[i]
        	 		    for t in range(60*60):
        	 		        stromPrisArrayDagensSekundforSekund.append(styringsProfilArray[i])
        	 		
        	 		#%% Instrument parameter
        	 		MaaleAvvikNivaa = 0.0 # [%]
        	 		MaaleAvvikStromning = 0.0 # [%]
        	 		
        	 		#%% Simulation Time Settings
        	 		t_start = 0  # [s]
        	 		t_stop = 60*60*timer # [s]
        	 		
        	 		#%% Signal parameter
        	 		u_min = 0 # [mA]
        	 		u_max = 16 # [mA]
        	 		u_range = u_max - u_min # [mA]
        	 		
        	 		#%% Reservoir parameter
        	 		reservoir_h_max = 7 # [m]
        	 		reservoir_h_min = 0 # [m]
        	 		reservoir_radius = 11 # [m]
        	 		reservoir_h_init = 2.8 # [m]
        	 		
        	 		#%% Pumpe parameter
        	 		pumpe_q_max = 0.033 # [m^3/s] - Volumetrisk strømning ved maks pådrag. Funnet ved 120m^3 / 60s*60s
        	 		pumpe_q_min = 0 # [m^3/s] - Volumetrisk strømning ved 4 mA
        	 		pumpe_q_init = 0.015 # [m^3/s] - Volumetrisk strømning ved første iterasjon | funnet ved totalstrømning fra begge pumpene / timer / 60*60
        	 		# 27.01.23 En forenklet versjon som ikke tar for seg mottrykk (net head) i røret og antatt linear pumpekurve
        	 		
        	 		def ReturnK_p(pumpe_q_max, u_range):
        	 		    k_p = (pumpe_q_max - pumpe_q_min) / u_range
        	 		    return k_p
        	 		
        	 		k_p = ReturnK_p(pumpe_q_max, u_range) # Forholdet mellom pådragssignal og volumetrisk strømning
        	 		
        	 		
        	 		#%% Innløpsventil parameter
        	 		C_v1 = 0.005 # [x] Valve flow coefficient
        	 		
        	 		#%% Utløpsventil parameter
        	 		C_v2 = 0.005 # [x] Valve flow coefficient
        	 		init = round(math.sqrt(reservoir_h_init) * C_v2, 3)
        	 		
        	 		#%% Primærsløyfe nivå-PI(D)-regulator parameter
        	 		ol_Kpu = 2 # Kritisk Forsterkning # 40.035
        	 		ol_Pu = 3000 # [s] Kritisk Periode # 483
        	 		ol_P = ol_Kpu*0.25 # proporsjonal forsterkning | ZN Relaxed
        	 		ol_I = ol_Pu*1.25 # Integraltid | ZN Relaxed
        	 		ol_D = 0 # Derivattid
        	 		ol_u_man = init # Manuelt pådrag | Stabiliserer seg på 40% ved 0.008365 i pådrag ved inner loop i auto
        	 		ol_settpunkt = 2.8 # Settpunkt i tanken | 40% i en 7m høy tank
        	 		ol_modus = "auto"
        	 		
        	 		#%% Sekundærsløyfe strømnings-PI(D)-regulator parameter
        	 		il_Kpu = 484.81 # Kritisk Forsterkning
        	 		il_Pu = 28 # Kristisk Periode
        	 		il_P = il_Kpu*0.25 # Proporsjonal forsterkning
        	 		il_I = il_Pu*1.25 # Intergraltid
        	 		il_D = 0 # Derivattid
        	 		il_u_man = 4.0566 # Manuelt pådrag
        	 		il_pv_init = pumpe_q_init
        	 		il_sp_init = init
        	 		il_modus = "auto"
        	 		
        	 		#%% Initialization of time delay flow in
        	 		f_delay = 120
        	 		N_delay_f = int(round(f_delay/1)) + 1
        	 		delay_array = array.array('f', [0] * N_delay_f)
        	 		
        	 		#%% Initialisering av tidsforsinkelse ved måling av strømning
        	 		f_meas_delay = int(f_delay/10)
        	 		N_delay_meas = int(round(f_meas_delay/1)) + 1
        	 		f_meas_delay_array = array.array('f', [0] * N_delay_meas)
        	 		
        	 		#%% Klasser 
        	 		def clip(x, xmin, xmax):
        	 		    return max(min(x, xmax), xmin)
        	 		    
        	 		class DataLagring:
        	 		    def __init__(self, t, h_t, f_in_t, f_out_t, settpunkt):
        	 		        self.t = t # Blir brukt som tid og indeks
        	 		        self.h_t = h_t # Høyden i bassenget som funksjon av tid
        	 		        self.f_in_t = f_in_t # Flow in som funksjon av tid, fått av pump.Flow()
        	 		        self.f_out_t = f_out_t # f_out_t # flow ut som funksjon av tid, fått av Reservoir.FlowOut()
        	 		        self.settpunkt = settpunkt
        	 		        self.u = pumpe_q_init # Muligens feil
        	 		        
        	 		        # Arrays til plotting | simulering
        	 		        self.t_array = array.array('f', [0] * t)
        	 		        self.h_t_array = array.array('f', [0] * t)
        	 		        self.f_in_t_array = array.array('f', [0] * t)
        	 		        self.f_out_t_array = array.array('f', [0] * t)
        	 		        self.settpunkt_array = array.array('f', [0] * t)
        	 		        self.u_f_array = array.array('f', [0] * t)
        	 		        self.u_h_array = array.array('f', [0] * t)
        	 		        self.e_array = array.array('f', [0] * t)
        	 		        self.il_u_i_forrige_array = array.array('f', [0] * t)
        	 		        self.ul_u_i_forrige_array = array.array('f', [0] * t)
        	 		    
        	 		class Reservoir:
        	 		    def __init__(self, h_max, h_min, radius, h_init):
        	 		        
        	 		        self.h_max = h_max
        	 		        self.h_min = h_min
        	 		        self.radius = radius
        	 		        self.areal = self.Areal()
        	 		        self.h = h_init
        	 		        
        	 		        # Avgrens min og maks nivå i tank
        	 		        self.h = clip(self.h, self.h_min, self.h_max)
        	 		        self.h_prosent = (self.h/self.h_max)*100
        	 		        
        	 		    def Areal(self):
        	 		        reservoir_areal = math.pi*self.radius**2
        	 		        return reservoir_areal
        	 		    
        	 		    def StatiskForbruk(self):
        	 		        flowOut = C_v2 * math.sqrt(self.h)
        	 		        return flowOut
        	 		        
        	 		class Pumpe:
        	 		    def __init__(self, K_p, u_min, u_max, u):
        	 		        
        	 		        self.K_p = K_p # [%] forsterkning
        	 		        self.u = u # [mA] pådragssignal
        	 		        self.u_max = u_max # [mA]
        	 		        self.u_min = u_min # [mA]
        	 		        
        	 		
        	 		    def FlowIn(self):
        	 		        flowIn = self.K_p * self.u 
        	 		        return flowIn # [m^3/s]
        	 		
        	 		class OuterLoopRegulator:
        	 		    def __init__(self, settpunkt, prosessverdi, P, I, D, u_man, modus):
        	 		        
        	 		        self.settpunkt = settpunkt
        	 		        self.prosessverdi = prosessverdi
        	 		        self.P = P
        	 		        self.I = I
        	 		        self.D = D
        	 		        self.u_man = u_man
        	 		        self.modus = modus.upper() # ".upper()" forhindrer syntax error ved store og små bokstaver
        	 		        self.u_i_forrige = u_man 
        	 		        self.e = self.Error()
        	 		        self.u = self.Paadrag()
        	 		        
        	 		    def Error(self):
        	 		        e = self.settpunkt - self.prosessverdi
        	 		        return e
        	 		    
        	 		    def Paadrag(self):
        	 		        if self.modus == "AUTO":
        	 		            # Bidrag fra proporsjonalleddet
        	 		            u_p = self.P * self.e
        	 		            
        	 		            # Bidraget fra integralleddet
        	 		            u_i = ((self.P / self.I) * self.e) + self.u_i_forrige
        	 		            
        	 		            # Regn ut total total forsterkning
        	 		            u = u_p + u_i # u_d | ikke implementert
        	 		            
        	 		            #Oppdater u_i_forrige + antiwindup
        	 		            if u > 0.033: # 16
        	 		                self.u_i_forrige = self.u_i_forrige
        	 		            elif u < 0:
        	 		                self.u_i_forrige = self.u_i_forrige
        	 		            else:   
        	 		                self.u_i_forrige = u_i
        	 		            
        	 		        elif self.modus == "MAN":
        	 		            # Manuell drift
        	 		            u = self.u_man
        	 		            
        	 		        else:
        	 		            # Feilmelding
        	 		            print("Vennligst skriv MAN eller AUTO")
        	 		            
        	 		        # Begrens pådragssignal til gitte rammer
        	 		        u = clip(u, 0, 0.033) # u_min, u_max
        	 		        return u
        	 		
        	 		class InnerLoopRegulator:
        	 		    def __init__(self, settpunkt, prosessverdi, P, I, D, u_man, modus):
        	 		        
        	 		        self.settpunkt = settpunkt
        	 		        self.prosessverdi = prosessverdi
        	 		        self.P = P
        	 		        self.I = I
        	 		        self.D = D
        	 		        self.u_man = u_man
        	 		        self.modus = modus.upper()
        	 		        self.u_i_forrige = u_man 
        	 		        self.e = self.Error()
        	 		        self.u = self.Paadrag()
        	 		        
        	 		    def Error(self):
        	 		        e = self.settpunkt - self.prosessverdi
        	 		        return e
        	 		        
        	 		    def Paadrag(self):
        	 		        if self.modus == "AUTO":
        	 		                
        	 		            # Bidrag fra proporsjonalleddet
        	 		            u_p = self.P * self.e
        	 		                
        	 		            # Bidraget fra integralleddet
        	 		            u_i = (self.P / self.I) * self.e + self.u_i_forrige
        	 		                
        	 		            # Regn ut totalforsterkning
        	 		            u = u_p + u_i # + u_d | u_d ikke implementert
        	 		                
        	 		            #Oppdater u_i_forrige + antiwindup
        	 		            if u > 16:
        	 		                self.u_i_forrige = self.u_i_forrige
        	 		            elif u < 0:
        	 		                self.u_i_forrige = self.u_i_forrige
        	 		            else:   
        	 		                self.u_i_forrige = u_i
        	 		            
        	 		        elif self.modus == "MAN":
        	 		            # Manuell drift
        	 		            u = self.u_man
        	 		            
        	 		        else:
        	 		            # Feilmelding
        	 		            print("Vennligst skriv MAN eller AUTO")
        	 		                
        	 		        # Begrens pådrag til gitte rammer
        	 		        u = clip(u, u_min, u_max)
        	 		        return u
        	 		                
        	 		
        	 		class Instrument:
        	 		    def __init__(self, prosessverdi, maaleavvik):
        	 		        
        	 		        self.prosessverdi = prosessverdi
        	 		        self.maaleavvik = maaleavvik
        	 		        
        	 		        def PVstoy(self):
        	 		            pass
        	 		
        	 		class Nivaamaaler(Instrument):
        	 		    def PVstoy(self):
        	 		        PVavvik = (self.prosessverdi * self.maaleavvik) / 100 
        	 		        PVstoy = random.uniform(self.prosessverdi - PVavvik, self.prosessverdi + PVavvik)
        	 		        return PVstoy
        	 		
        	 		class Stromningsmaaler(Instrument):
        	 		    def PVstoy(self):
        	 		        PVavvik = (self.prosessverdi * self.maaleavvik) / 100 
        	 		        PVstoy = random.uniform(self.prosessverdi - PVavvik, self.prosessverdi + PVavvik)
        	 		        return PVstoy
        	 		           
        	 		#%% Opprett objekter av klassene
        	 		mittReservoir = Reservoir(reservoir_h_max, reservoir_h_min, reservoir_radius, reservoir_h_init)
        	 		outerLoopRegulator = OuterLoopRegulator(ol_settpunkt, mittReservoir.h, ol_P, ol_I, ol_D, ol_u_man, ol_modus)
        	 		innerLoopRegulator = InnerLoopRegulator(outerLoopRegulator.Paadrag(), il_pv_init, il_P, il_I, il_D, il_u_man, il_modus)
        	 		minPumpe = Pumpe(k_p, u_min, u_max, innerLoopRegulator.Paadrag())
        	 		minDataLagring = DataLagring(t_stop, mittReservoir.h, minPumpe.FlowIn(), mittReservoir.StatiskForbruk(), outerLoopRegulator.settpunkt)
        	 		minNivaamaaler = Nivaamaaler(mittReservoir.h, MaaleAvvikNivaa)
        	 		minStromningsmaaler = Stromningsmaaler(minPumpe.FlowIn(), MaaleAvvikStromning)
        	 		
        	 		
        	 		#%% Program-loop
        	 		
        	 		# Denne løkken simulerer fullt innløp
        	 		i = 0
        	 		while i < f_meas_delay and system.tag.read("Start").value == True:
        	 		    f_meas_delay_array[i] = init
        	 		    i += 1
        	 		
        	 		t = t_start
        	 		while t < t_stop and system.tag.read("Start").value == True:
        	 		    # forsinker innstrømning i tanken med 120 iterasjoner | bare valgt et tall her
        	 		    f_in_delayed = delay_array[-1]
        	 		    delay_array[1:] = delay_array[0:-1]
        	 		    delay_array[0] = minPumpe.FlowIn()
        	 		    
        	 		    # dh_dt = f_in - f_out / A
        	 		    dh_dt = (f_in_delayed - mittReservoir.StatiskForbruk()) / mittReservoir.Areal() # | *60 for minutter istedet for sekunder
        	 		    
        	 		    # Mitt reservoir.h oppdaterer høyden i tanken per iterasjon
        	 		    mittReservoir.h += dh_dt
        	 		    
        	 		    # Måler nivå med Nivåmåler
        	 		    minNivaamaaler.prosessverdi = mittReservoir.h
        	 		    
        	 		    # Oppdater outer loop regulatoren PV | med støy
        	 		    outerLoopRegulator.prosessverdi = minNivaamaaler.PVstoy()
        	 		    
        	 		    # Oppdater outer loop error
        	 		    outerLoopRegulator.e = outerLoopRegulator.Error()
        	 		    
        	 		    # Send outerLoop u til inner loop SP
        	 		    innerLoopRegulator.settpunkt = outerLoopRegulator.Paadrag()
        	 		    
        	 		    # Forsinker strømningsmåleren med 12 sekunder
        	 		    f_meas_delayed = f_meas_delay_array[-1]
        	 		    f_meas_delay_array[1:] = f_meas_delay_array[0:-1]
        	 		    f_meas_delay_array[0] = minPumpe.FlowIn()
        	 		    
        	 		    # Måler strømning med strømningsmåler
        	 		    minStromningsmaaler.prosessverdi = f_meas_delayed
        	 		    
        	 		    # Oppdater sekundær regulator PV
        	 		    innerLoopRegulator.prosessverdi = minStromningsmaaler.PVstoy()
        	 		    
        	 		    # Oppdater inner loop error
        	 		    innerLoopRegulator.e = innerLoopRegulator.Error()
        	 		    
        	 		    # Generer nytt pådrag til pumpa
        	 		    if stromPrisArrayDagensSekundforSekund[t] == 1:
        	 		            minPumpe.u = innerLoopRegulator.Paadrag()
        	 		    elif innerLoopRegulator.modus == "man":
        	 		            minPumpe.u = innerLoopRegulator.Paadrag()
        	 		    else:
        	 		    	minPumpe.u = 0
        	 		            
        	 		   
        	 			     
        	 		    # Lagring av verdier til Datalagringsklassen
        	 		    minDataLagring.t_array[t] = t
        	 		    minDataLagring.h_t_array[t] = minNivaamaaler.PVstoy()
        	 		    minDataLagring.f_in_t_array[t] = minStromningsmaaler.PVstoy()
        	 		    minDataLagring.f_out_t_array[t] = mittReservoir.StatiskForbruk()
        	 		    minDataLagring.settpunkt_array[t] = outerLoopRegulator.settpunkt
        	 		    minDataLagring.u_f_array[t] = innerLoopRegulator.Paadrag()
        	 		    minDataLagring.u_h_array[t] = outerLoopRegulator.Paadrag()
        	 		    minDataLagring.e_array[t] = outerLoopRegulator.e
        	 		    minDataLagring.il_u_i_forrige_array[t] = innerLoopRegulator.u_i_forrige
        	 		    minDataLagring.ul_u_i_forrige_array[t] = outerLoopRegulator.u_i_forrige
        	 		    
        	 		     #Gjør om Verdier til Prosent
        	 		    Nivaa_prosent = (minDataLagring.h_t_array[t]/7)*100
        	 		    PumpePaadrag = minPumpe.u/(u_max-u_min)*100
        	 		    FlowIn = minDataLagring.f_in_t_array[t]*3600
        	 		    FlowOut = minDataLagring.f_out_t_array[t]*3600
        	 		    time.sleep(1/speed)
        	 		    # Skriver til Tag Nivaa
        	 		    system.tag.writeBlocking(["Nivaats"],[Nivaa_prosent])
        	 		    system.tag.writeBlocking(["PumpePaadrag"],[PumpePaadrag])
        	 		    system.tag.writeBlocking(["FlowIn"],[FlowIn])
        	 		    system.tag.writeBlocking(["FlowOut"],[FlowOut])
        	 		    t += 1
